To open the Compile Time Tracker window use the 'Window -> Compile Time Tracker Window' menu item.

Compile time is logged to the console automatically, but can be disabled from the tracker window.